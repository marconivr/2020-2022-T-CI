# AGENT

**#python #inventory #os #network #eventviewer #wmi #apps #batch #synchronization**

## Description

### This software is a collection of five different programs:

1. ### NETINFO
    netinfo.py is a program that collects information about the network adapters of a computer. The information then gets stored into a file called *computername_netinfo.csv*.

2. ### OSVERSION
    osversion.py is a program that collects information about the operative system of a computer. It then stores this information in a file called *computername_osversion.csv*.

3. ### PRODUCT
    product.py is a program that collects information about the apps installed on a computer. The information is then stored on a file called *computername_product.csv*.

4. ### EVENTSVIEW
    eventsview.py is a program that collects information about the events registered in the Windows Event Viewer. Like in the Windows Event Viewer, when executing agent.jar you will have the option to select which "log file" to analyze and, optionally, you can also select which type of warning you want to store on the file *computername_events.csv*.

5. ### SYNC FILES
    This program will allow you to copy your csv files and your log files to a specified location. When executing it, you will have to indicate in which directory you want your files to be stored. The path can either point to a local directory or to a network directory.

The execution of each file is traced in *computername_agentlog.log*.

## Requirements

- Python 3 ([Click here to download it](https://www.python.org/downloads/))
- Java JDK 15 ([Click here to download it](https://www.oracle.com/it/java/technologies/javase-downloads.html))

## File structure

- bin
  * agent.jar
  * agent.bat
  * sync.bat
  * netinfo.py
  * osversion.py
  * product.py
  * eventsview.py
  * functions.py

- doc
  * README.md
  * Images
    - computers.png
    - agent_correct.png
    - agent_missing.png
    - agent_notexist.png
    - agent_file.png

- flussi
  * computers.csv
  * computername_netinfo.csv
  * computername_osversion.csv
  * computername_product.csv
  * computername_events.csv
  
- log
  * computername_agentlog.log

- sync (Folder created to test *Sync files*, not necessary!)
  * flussi
    - computername_netinfo.csv
    - computername_osversion.csv
    - computername_product.csv
    - computername_events.csv
  * log
    - computername_agentog.log

## Execution example (GUI)

  - First, make sure to insert in *computers.csv* (from the second line on, don't delete "Node;" !) all the names or the IP addresses of the computers you want to analyze.
  - Then just double click on agent.jar, select the programs that you want to execute and click on *Run*.

    ![](../doc/Images/computers.png)
    ![](../doc/Images/agent_correct.png)

  - ### Note:
     If you choose to execute *Sync files*, agent.jar will automatically detect if the path for the directory is missing, is non existent or if it represents a file.

     ![](../doc/Images/agent_missing.png)
     ![](../doc/Images/agent_notexist.png)
     ![](../doc/Images/agent_file.png)

## Execution example (CLI)

This software is also usable by CLI.

- For the programs netinfo.py, osversion.py and product.py, no parameters are required.

  For example:

      python netinfo.py

      python osversion.py

- For eventsview.py, you must specify the log file to analize (System or Application) and you can also optionally choose the type of warning to register (Information, Warning, Error or Critical).

  For example:

      python eventsview.py System

      python eventsview.py Application Error

- For sync.bat you must specify a path, and the program will notify you if the directory inserted does not exit. Unlike the GUI version though, it will not notify you if the path inserted points to a file and not to a directory.

  For example:

      sync.bat C:\Users\Claudio\Documents\sync

- You can also launch the programs using agent.bat. It works by giving as parameters the names of the programs to execute. The only exception is for eventsview: in that case you'll have to use the format *eventsview_Logfile* or *eventsview_Logfile_Errorlevel*.

  For example:

      agent.bat netinfo osversion product eventsview_System

      agent.bat product osversion eventsview_Application_Warning

  Just rember to type the log file and the error level with the first letter being uppercase and the rest of the word being lowercase.

## Author

Claudio Foroncelli

# Changelog

## [01.01] - 2021-01-17

### Added

- First version
